# TikTok Shop UK campaign case study — outline

Brand: Réalisation Par (real brand, UK market). ALL figures illustrative.
Note: no brand logo, wordmark or proprietary print is reproduced — the piece is set in
the project's Modernist system. Brand is the SUBJECT, not the visual source.

Scenario: product launch — a UK-exclusive silk drop sold through TikTok Shop UK over a
14-day window (2–15 Nov 2026), timed to the Mount Street flagship's viral film photo booth.

Objective: acquire first-time UK buyers on TikTok Shop by converting the store's organic
photo-booth attention into a shoppable launch moment, at a target CVR of 2.0%.

## Deck title sequence (short topic noun-phrases, one style throughout)
1. TikTok Shop UK — Silk Drop Launch  (cover)
2. Campaign Context
3. Headline Results
4. Performance Over the Window
5. Revenue Efficiency by Content Format
6. Creator Partner Comparison
7. What Worked
8. What Didn't
9. Recommendations
10. Method and Caveats

Read back: context -> results -> two charts -> diagnosis -> actions -> method. Follows.

## Numbers (illustrative)
8.06M views | 1,691 units | GMV £279,015 | AOV £165 | blended CVR 1.8%
Peaks: Day 7 brand LIVE (£51,810 = 19% of GMV in 7% of the window)
       Day 11 UGC spike (1.18M views, CVR floor 1.2%)
Dead zone: Days 4–6, no scheduled content, GMV -72% off Day 3
Efficiency: LIVE £5,632/100k views vs UGC £2,454/100k views
Inverse creator relationship: micro @sophie.linnell £5,895/100k vs macro £3,038/100k
